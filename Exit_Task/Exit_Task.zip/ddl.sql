CREATE TABLE file_names (
    filename   VARCHAR2(150)
);

CREATE TABLE dim_customers(
    cust_dm_id         NUMBER(38),
    id              NUMBER(38),
    name            VARCHAR2(255 BYTE),
    username        VARCHAR2(255 BYTE),
    email           VARCHAR2(255 BYTE),
    dateofbirth     DATE,
    streetaddress   VARCHAR2(255 BYTE),
    city            VARCHAR2(255 BYTE),
    country         VARCHAR2(13 BYTE),
    zip             VARCHAR2(6 BYTE),
    state           VARCHAR2(3 BYTE),
    phone           VARCHAR2(14 BYTE)
);

CREATE TABLE dim_products (
    prod_dm_id             NUMBER(38),
    products                 NUMBER(38),
    productname              VARCHAR2(255 BYTE),
    companyname              VARCHAR2(255 BYTE),
    price                    NUMBER(9,3),
    warehouselocationstate   VARCHAR2(10 BYTE)
);

 
 CREATE TABLE cls_customer(
   
    id              NUMBER(38),
    name            VARCHAR2(255 BYTE),
    username        VARCHAR2(255 BYTE),
    email           VARCHAR2(255 BYTE),
    dateofbirth     DATE,
    streetaddress   VARCHAR2(255 BYTE),
    city            VARCHAR2(255 BYTE),
    country         VARCHAR2(13 BYTE),
    zip             VARCHAR2(6 BYTE),
    state           VARCHAR2(3 BYTE),
    phone           VARCHAR2(14 BYTE),
     cust_dm_id         NUMBER(38) primary key
);

CREATE TABLE cls_products (
    products                 NUMBER(38),
    productname              VARCHAR2(255 BYTE),
    companyname              VARCHAR2(255 BYTE),
    price                    NUMBER(9,3),
    warehouselocationstate   VARCHAR2(10 BYTE),
    prod_dm_id               NUMBER(38) PRIMARY KEY
);
CREATE TABLE cls_credit_cards (
    creditcard_dm_id   NUMBER(10) PRIMARY KEY,
    creditcard         VARCHAR2(100 BYTE),
    creditcardnumber   VARCHAR2(100 BYTE)
);

CREATE TABLE dim_credit_cards (
    creditcard_dm_id   NUMBER(10) PRIMARY KEY,
    creditcard         VARCHAR2(100 BYTE),
    creditcardnumber   VARCHAR2(100 BYTE)
);

CREATE SEQUENCE seq_cls_card
 START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;

CREATE SEQUENCE seq_cls_cust
 START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;

CREATE SEQUENCE seq_cls_prod
 START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;
 
